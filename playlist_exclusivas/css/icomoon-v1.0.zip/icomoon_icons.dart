// Place fonts/icomoon.ttf in your fonts/ directory and
// add the following to your pubspec.yaml
// flutter:
//   fonts:
//    - family: icomoon
//      fonts:
//       - asset: fonts/icomoon.ttf
import 'package:flutter/widgets.dart';

class Icomoon {
  Icomoon._();

  static const String _fontFamily = 'icomoon';

  static const IconData youtubemusic = IconData(0xe905, fontFamily: _fontFamily);
  static const IconData deezer = IconData(0xe900, fontFamily: _fontFamily);
  static const IconData instagram = IconData(0xe908, fontFamily: _fontFamily);
  static const IconData soundcloud = IconData(0xe901, fontFamily: _fontFamily);
  static const IconData spotify = IconData(0xe902, fontFamily: _fontFamily);
  static const IconData tiktok = IconData(0xe909, fontFamily: _fontFamily);
  static const IconData twitter = IconData(0xe903, fontFamily: _fontFamily);
  static const IconData youtube = IconData(0xe904, fontFamily: _fontFamily);
  static const IconData home = IconData(0xe90a, fontFamily: _fontFamily);
}
